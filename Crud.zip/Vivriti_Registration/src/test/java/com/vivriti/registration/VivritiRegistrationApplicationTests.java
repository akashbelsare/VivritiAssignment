package com.vivriti.registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VivritiRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}

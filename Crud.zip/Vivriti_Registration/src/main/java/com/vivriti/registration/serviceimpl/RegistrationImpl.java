/**
 * 
 */
package com.vivriti.registration.serviceimpl;

import java.sql.SQLException;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vivriti.registration.Exception.RegisteratioException;
import com.vivriti.registration.entity.User;
import com.vivriti.registration.repository.RegistrationRepository;
import com.vivriti.registration.service.RegistrationService;

/**
 * @author Belsare
 *
 */

@Service
public class RegistrationImpl implements RegistrationService {

	@Autowired
	RegistrationRepository regRepo;

	@Override
	public User addUserDetails(User user) throws SQLException {

		return regRepo.save(user);
	}

	@Override
	public User updateDetails(User user, Integer id) {

		User userDB = regRepo.findById(id).get();

		if (Objects.nonNull(user.getFirstName()) && !"".equalsIgnoreCase(user.getFirstName())) {
			userDB.setFirstName(user.getFirstName());
		}

		if (Objects.nonNull(user.getLastName()) && !"".equalsIgnoreCase(user.getLastName())) {
			userDB.setLastName(user.getLastName());
		}
		/*
		 * if (Objects.nonNull(user.getDateOfBirth()) && !"".equalsIgnoreCase(
		 * user.getDateOfBirth())) { userDB.setDateOfBirth( user.getDateOfBirth()); }
		 */

		if (Objects.nonNull(user.getUsername()) && !"".equalsIgnoreCase(user.getUsername())) {
			userDB.setUsername(user.getUsername());
		}

		if (Objects.nonNull(user.getPassword()) && !"".equalsIgnoreCase(user.getPassword())) {
			userDB.setPassword(user.getPassword());
		}

		return regRepo.save(userDB);

	}

	@Override
	public void deleteUser(Integer id) {

		regRepo.deleteById(id);

	}

	@Override
	public Optional<User> getUserById(Integer Id) {

		Optional<User> user = regRepo.findById(Id);// null
		if (user == null) { // 6==null or null==null
			throw new RegisteratioException("User id " + Id + " incorrect..");
		}
		return user;

	}
}

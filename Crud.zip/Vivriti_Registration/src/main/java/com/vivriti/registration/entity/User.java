/**
 * 
 */
package com.vivriti.registration.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author Belsare
 *
 */

@Entity
@Table(name="vivritiRegistration")
public class User implements Serializable {

private static final long serialVersionUID = 1L;
		
		@Id	
	    @GeneratedValue(strategy = GenerationType.AUTO)
	
	   private int user_Id;
		
	@Column(name="firstName")
	   private String firstName;
		
	@Column(name="lastName")
		private  String lastName;
		
		
		@DateTimeFormat(pattern="yyyy-MM-dd")
		private Date dateOfBirth;
		
	
		private String username;
		
		
		private String password;


		public int getUser_Id() {
			return user_Id;
		}


		public void setUser_Id(int user_Id) {
			this.user_Id = user_Id;
		}


		public String getFirstName() {
			return firstName;
		}


		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}


		public String getLastName() {
			return lastName;
		}


		public void setLastName(String lastName) {
			this.lastName = lastName;
		}


		public Date getDateOfBirth() {
			return dateOfBirth;
		}


		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}


		public String getUsername() {
			return username;
		}


		public void setUsername(String username) {
			this.username = username;
		}


		public String getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password = password;
		}


		public static long getSerialversionuid() {
			return serialVersionUID;
		}


		@Override
		public int hashCode() {
			return Objects.hash(dateOfBirth, firstName, lastName, password, user_Id, username);
		}


		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			User other = (User) obj;
			return Objects.equals(dateOfBirth, other.dateOfBirth) && Objects.equals(firstName, other.firstName)
					&& Objects.equals(lastName, other.lastName) && Objects.equals(password, other.password)
					&& user_Id == other.user_Id && Objects.equals(username, other.username);
		}


		@Override
		public String toString() {
			return "User [user_Id=" + user_Id + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
					+ dateOfBirth + ", username=" + username + ", password=" + password + "]";
		}


		public User() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		

}
package com.vivriti.registration.Exception;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus  //id is incorrect
public class RegisteratioException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public RegisteratioException(String message){
		super(message); //calling
	}

}

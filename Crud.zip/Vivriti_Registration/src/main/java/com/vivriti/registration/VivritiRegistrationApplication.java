package com.vivriti.registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VivritiRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(VivritiRegistrationApplication.class, args);
	}

}

/**
 * 
 */
package com.vivriti.registration.service;

import java.sql.SQLException;
import java.util.Optional;

import com.vivriti.registration.entity.User;

/**
 * @author Belsare
 *
 */
public interface RegistrationService {

	User addUserDetails(User user) throws SQLException;

	User updateDetails(User user, Integer id);

	public void deleteUser(Integer id);

	public Optional<User> getUserById(Integer Id);

}

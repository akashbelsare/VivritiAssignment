package com.vivriti.assignment;

import java.util.ArrayList;

/**
 * @author Belsare
 *
 */
public class ListAverage {
	 
    /**
     * @param args
     */
    public static void main(String[] args) {
        
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(15);
        arrayList.add(22);
        arrayList.add(18);
        arrayList.add(35);
        arrayList.add(18);
         
        double sum = 0.0;
        
     
        for(int no:arrayList) {
            sum = sum+no;      
        }
         
      
        double average = (sum / arrayList.size()); 
         
        System.out.println("Average of Elements =  "+average);
    }
}



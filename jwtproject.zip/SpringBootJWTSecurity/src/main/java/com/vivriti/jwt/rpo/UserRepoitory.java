package com.vivriti.jwt.rpo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vivriti.jwt.model.User;

public interface UserRepoitory extends JpaRepository<User, Integer> {
	User findByUsername(String username);

}

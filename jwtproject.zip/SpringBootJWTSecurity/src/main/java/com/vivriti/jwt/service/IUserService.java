package com.vivriti.jwt.service;

import com.vivriti.jwt.model.User;

public interface IUserService {
	Integer saveUser(User user);

}
